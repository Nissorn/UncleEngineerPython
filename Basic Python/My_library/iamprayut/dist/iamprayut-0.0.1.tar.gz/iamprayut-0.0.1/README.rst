This package have information about Prayut
==========================================

PyPi: https://pypi.org/project/iamprayut/

Hello this is package information about Prayut Chan-O-Cha

วิธีติดตั้ง
~~~~~~~~~~~

เปิด CMD / Terminal

.. code:: python

   pip install iamprayut

วิธีใช้งานแพ็คเพจนี้
~~~~~~~~~~~~~~~~~~~~

-  เปิด IDLE ขึ้นมาแล้วพิมพ์…

\```python from iamprayut import Prayut

mayor = Prayut() #Class mayor.show_name() #show name mayor.show_page()
#show facebook page mayor.about() #show about him mayor.show_art() #show
ascii art
